<?php

// Load Child Theme Styles
  function child_theme_styles() {
    wp_dequeue_style( 'parent-theme-style' );
    wp_enqueue_style( 'child-theme-style', get_stylesheet_directory_uri() .'/css/style.css' );
  }
  add_action( 'wp_enqueue_scripts', 'child_theme_styles', 99 );

// Load Child Theme Scripts
  function child_theme_scripts() {
    wp_register_script( 'childscripts', get_stylesheet_directory_uri() . '/js/scripts.js', array('jquery'),'', true);
    wp_enqueue_script( 'childscripts' );
  }
  add_action( 'wp_enqueue_scripts', 'child_theme_scripts' );
